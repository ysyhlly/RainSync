//! Explicitly opt-in, fenced room control. Media state remains single-authority.
mod http_policy;
mod lifecycle;
mod peer_transport;
pub use peer_transport::proxy_socket;
mod route_resolution;

use crate::*;
use axum::body::{Body, to_bytes};
use axum::extract::Request;
use axum::middleware::Next;
use futures_util::StreamExt;
use http_policy::{forward_response_headers, guest_rate_identity, node_route, room_path};
use persistence::room_node_leases::{self as leases, Lease, Route};
use std::collections::{BTreeMap, HashSet};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::time::Duration;

const PEER: &str = "x-rainsync-control-peer";
const SECRET: &str = "x-rainsync-control-secret";
const GUEST_RATE_IDENTITY: &str = "x-rainsync-control-guest-rate-identity";
const MAX_BODY: usize = 65536;
const MAX_RESPONSE: usize = 1048576;
const DEADLINE: Duration = Duration::from_secs(5);

#[derive(Clone)]
pub struct Settings {
    pub node: Uuid,
    pub instance: Uuid,
    media: bool,
    nodes: BTreeMap<Uuid, String>,
    secret: String,
}
impl Settings {
    pub fn from_env() -> anyhow::Result<Option<Self>> {
        match std::env::var("RAINSYNC_CONTROL_CLUSTER").as_deref() {
            Err(_) | Ok("0") => return Ok(None),
            Ok("1") => (),
            _ => anyhow::bail!("RAINSYNC_CONTROL_CLUSTER must be 0 or 1"),
        }
        let node = Uuid::parse_str(&std::env::var("RAINSYNC_CONTROL_NODE_ID")?)?;
        anyhow::ensure!(!node.is_nil(), "invalid control node ID");
        let media = match std::env::var("RAINSYNC_CONTROL_ROLE").as_deref() {
            Ok("media") => true,
            Ok("control") => false,
            _ => anyhow::bail!("RAINSYNC_CONTROL_ROLE must be media or control"),
        };
        let raw: BTreeMap<Uuid, String> =
            serde_json::from_str(&std::env::var("RAINSYNC_CONTROL_NODES")?)?;
        anyhow::ensure!(
            !raw.is_empty() && raw.len() <= 32 && raw.contains_key(&node),
            "invalid control node allowlist"
        );
        let mut nodes = BTreeMap::new();
        for (id, origin) in raw {
            anyhow::ensure!(!id.is_nil(), "invalid control node ID");
            nodes.insert(id, normalize_origin(&origin)?);
        }
        let secret = std::env::var("RAINSYNC_CONTROL_PEER_TOKEN")?;
        anyhow::ensure!(
            (32..=256).contains(&secret.len()) && secret.bytes().all(|b| (33..=126).contains(&b)),
            "invalid control peer token"
        );
        Ok(Some(Self {
            node,
            instance: Uuid::new_v4(),
            media,
            nodes,
            secret,
        }))
    }
    pub fn media_authority(&self) -> bool {
        self.media
    }
    fn fingerprint(&self) -> String {
        hash(&json!([self.nodes, hash(&self.secret)]).to_string())
    }
}
fn normalize_origin(value: &str) -> anyhow::Result<String> {
    let url = reqwest::Url::parse(value)?;
    let local = matches!(
        url.host_str(),
        Some("localhost" | "127.0.0.1" | "[::1]" | "::1")
    );
    anyhow::ensure!(
        value.len() <= 512
            && (url.scheme() == "https" || url.scheme() == "http" && local)
            && url.username().is_empty()
            && url.password().is_none()
            && url.query().is_none()
            && url.fragment().is_none()
            && url.path() == "/",
        "invalid control node origin"
    );
    Ok(url.as_str().trim_end_matches('/').into())
}

#[derive(Clone)]
pub struct Runtime {
    inner: Arc<Inner>,
}
struct Inner {
    settings: Settings,
    db: PgPool,
    epoch: Uuid,
    start: Instant,
    live: AtomicBool,
    create_route: AtomicU64,
    owned: Mutex<HashMap<Uuid, Lease>>,
    fenced: Mutex<HashSet<Uuid>>,
    routes: Mutex<HashMap<Uuid, (Instant, Route)>>,
    http: reqwest::Client,
}
impl Runtime {
    fn now(&self) -> f64 {
        self.inner.start.elapsed().as_secs_f64() * 1000.0
    }
    pub fn node(&self) -> Uuid {
        self.inner.settings.node
    }
    pub fn close(&self) {
        self.inner.live.store(false, Ordering::Release);
    }
    pub fn healthy(&self) -> bool {
        self.inner.live.load(Ordering::Acquire)
    }
    pub fn media_authority(&self) -> bool {
        self.inner.settings.media
    }
    pub async fn owns(&self, lease: &Lease) -> bool {
        self.healthy()
            && self
                .inner
                .owned
                .lock()
                .await
                .get(&lease.room)
                .is_some_and(|current| current.fencing_token == lease.fencing_token)
    }
    pub async fn local_lease(&self, room: Uuid) -> anyhow::Result<Lease> {
        tokio::time::timeout(DEADLINE, self.local_lease_inner(room))
            .await
            .map_err(|_| anyhow::anyhow!("room_owner_unavailable"))?
    }
    async fn local_lease_inner(&self, room: Uuid) -> anyhow::Result<Lease> {
        anyhow::ensure!(self.healthy(), "control_node_unhealthy");
        anyhow::ensure!(
            !self.inner.fenced.lock().await.contains(&room),
            "room_owner_lost"
        );
        let mut owned = self.inner.owned.lock().await;
        if let Some(lease) = owned.get(&room) {
            return Ok(lease.clone());
        }
        let retired = self.inner.fenced.lock().await.len();
        anyhow::ensure!(owned.len() + retired < 1024, "control_room_budget_exceeded");
        let lease = tokio::time::timeout(
            Duration::from_secs(3),
            leases::claim(&self.inner.db, room, self.node()),
        )
        .await??
        .ok_or_else(|| anyhow::anyhow!("room_owner_changed"))?;
        anyhow::ensure!(
            lease.incarnation == self.inner.settings.instance,
            "control_node_incarnation_lost"
        );
        leases::prepare(&self.inner.db, &lease, self.inner.epoch, self.now()).await?;
        owned.insert(room, lease.clone());
        Ok(lease)
    }
    pub async fn invalidate(&self, room: Uuid) {
        self.inner.routes.lock().await.remove(&room);
    }
    fn trusted(&self, route: &Route) -> anyhow::Result<()> {
        anyhow::ensure!(
            self.inner.settings.nodes.get(&route.node) == Some(&route.origin),
            "untrusted_control_route"
        );
        Ok(())
    }
    async fn new_room_route(&self) -> anyhow::Result<Route> {
        let rows=tokio::time::timeout(Duration::from_secs(2),sqlx::query("SELECT id,route_origin FROM control_nodes WHERE heartbeat_at>clock_timestamp()-interval '10 seconds' ORDER BY id LIMIT 32").fetch_all(&self.inner.db)).await??;
        let mut nodes: Vec<Route> = rows
            .into_iter()
            .filter_map(|row| {
                let route = Route {
                    node: row.get("id"),
                    origin: row.get("route_origin"),
                    fencing_token: 0,
                    remaining_ms: 0,
                };
                self.trusted(&route).ok().map(|_| route)
            })
            .collect();
        anyhow::ensure!(!nodes.is_empty(), "room_owner_unavailable");
        let local = nodes
            .iter()
            .position(|node| node.node == self.node())
            .unwrap_or(0);
        let next = self.inner.create_route.fetch_add(1, Ordering::Relaxed) as usize;
        let index = (local + next) % nodes.len();
        Ok(nodes.swap_remove(index))
    }
    fn peer(&self, h: &HeaderMap) -> bool {
        let Some(node) = h
            .get(PEER)
            .and_then(|v| v.to_str().ok())
            .and_then(|v| Uuid::parse_str(v).ok())
        else {
            return false;
        };
        let Some(secret) = h.get(SECRET).and_then(|v| v.to_str().ok()) else {
            return false;
        };
        let lhs = Sha256::digest(secret.as_bytes());
        let rhs = Sha256::digest(self.inner.settings.secret.as_bytes());
        self.inner.settings.nodes.contains_key(&node)
            && lhs.iter().zip(rhs).fold(0u8, |a, (x, y)| a | (x ^ y)) == 0
    }
}

pub fn routes() -> Router<App> {
    Router::new().route("/_rainsync/control/ws/{room}", get(peer_socket))
}
async fn peer_socket(
    State(app): State<App>,
    Path(room): Path<Uuid>,
    h: HeaderMap,
    ws: WebSocketUpgrade,
) -> Result<Response> {
    let cluster = app
        .control_cluster
        .as_ref()
        .ok_or_else(|| err(StatusCode::NOT_FOUND, "not_found"))?;
    if !cluster.peer(&h) {
        return Err(err(StatusCode::FORBIDDEN, "control_peer_rejected"));
    }
    let user_id = h
        .get("x-rainsync-control-user")
        .and_then(|v| v.to_str().ok())
        .and_then(|v| Uuid::parse_str(v).ok())
        .ok_or_else(|| err(StatusCode::FORBIDDEN, "control_peer_rejected"))?;
    let session = h
        .get("x-rainsync-control-session")
        .and_then(|v| v.to_str().ok())
        .filter(|v| v.len() == 64 && v.bytes().all(|b| b.is_ascii_hexdigit()))
        .ok_or_else(|| err(StatusCode::FORBIDDEN, "control_peer_rejected"))?
        .to_string();
    let admin:Option<bool>=tokio::time::timeout(Duration::from_secs(2),sqlx::query_scalar("SELECT u.admin FROM sessions s JOIN users u ON u.id=s.user_id JOIN room_members m ON m.user_id=u.id AND m.room_id=$3 WHERE s.token_hash=$1 AND s.user_id=$2 AND s.expires_at>clock_timestamp() AND playback_login_allowed(u.id,s.token_hash) AND (guest_is_account(u.id) OR guest_room_allowed(u.id,$3))")
        .bind(&session).bind(user_id).bind(room).fetch_optional(&app.db)).await
        .map_err(|_|err(StatusCode::SERVICE_UNAVAILABLE,"room_owner_unavailable"))??;
    let user = User {
        id: user_id,
        admin: admin.ok_or_else(|| err(StatusCode::FORBIDDEN, "session_expired"))?,
    };
    let route = cluster
        .resolve(room)
        .await
        .map_err(|_| err(StatusCode::SERVICE_UNAVAILABLE, "room_owner_changed"))?;
    if route.node != cluster.node() {
        return Err(err(StatusCode::CONFLICT, "room_owner_changed"));
    }
    Ok(ws
        .max_message_size(MAX_BODY)
        .max_frame_size(MAX_BODY)
        .on_upgrade(move |socket| rooms::socket_on_owner(app, user, socket, session)))
}

pub async fn middleware(State(app): State<App>, mut request: Request, next: Next) -> Response {
    let Some(cluster) = app.control_cluster.as_ref() else {
        return next.run(request).await;
    };
    if !cluster.healthy() {
        return err(StatusCode::SERVICE_UNAVAILABLE, "control_node_unhealthy").into_response();
    }
    let path = request.uri().path();
    let peer = cluster.peer(request.headers());
    if (request.headers().contains_key(PEER) || request.headers().contains_key(SECRET)) && !peer {
        return err(StatusCode::FORBIDDEN, "control_peer_rejected").into_response();
    }
    if path.starts_with("/_rainsync/control/") {
        return if peer {
            next.run(request).await
        } else {
            err(StatusCode::FORBIDDEN, "control_peer_rejected").into_response()
        };
    }
    let room = room_path(path);
    let guest_entry = request.method() == axum::http::Method::POST
        && path
            .strip_prefix("/api/v1/rooms/")
            .and_then(|rest| rest.split_once('/'))
            .is_some_and(|(room, tail)| tail == "guest-session" && Uuid::parse_str(room).is_ok());
    let guest_identity = if guest_entry {
        match guest_rate_identity(&app.account_security, &request, peer) {
            Ok(identity) => Some(identity),
            Err(error) => return error.into_response(),
        }
    } else {
        None
    };
    let route = if path == "/api/v1/rooms" && request.method() == axum::http::Method::POST && !peer
    {
        match cluster.new_room_route().await {
            Ok(route) => route,
            Err(_) => {
                return err(StatusCode::SERVICE_UNAVAILABLE, "room_owner_unavailable")
                    .into_response();
            }
        }
    } else if let Some(room) = room {
        match cluster.resolve(room).await {
            Ok(route) => route,
            Err(_) => {
                return err(StatusCode::SERVICE_UNAVAILABLE, "room_owner_unavailable")
                    .into_response();
            }
        }
    } else {
        return if cluster.media_authority() || node_route(path) {
            next.run(request).await
        } else {
            err(StatusCode::SERVICE_UNAVAILABLE, "media_authority_required").into_response()
        };
    };
    if route.node == cluster.node() {
        if let Some(identity) = guest_identity {
            request.extensions_mut().insert(identity);
        }
        return next.run(request).await;
    }
    if peer {
        return err(StatusCode::CONFLICT, "room_owner_changed").into_response();
    }
    let (parts, body) = request.into_parts();
    let body = match tokio::time::timeout(DEADLINE, to_bytes(body, MAX_BODY)).await {
        Ok(Ok(body)) => body,
        _ => {
            return err(StatusCode::PAYLOAD_TOO_LARGE, "control_request_too_large").into_response();
        }
    };
    let uri = format!(
        "{}{}",
        route.origin,
        parts.uri.path_and_query().map_or("", |p| p.as_str())
    );
    let mut outgoing = cluster
        .inner
        .http
        .request(parts.method, uri)
        .header(PEER, cluster.node().to_string())
        .header(SECRET, &cluster.inner.settings.secret)
        .body(body);
    if let Some(identity) = guest_identity {
        outgoing = outgoing.header(GUEST_RATE_IDENTITY, identity.as_str());
    }
    for name in [
        header::COOKIE,
        header::ORIGIN,
        header::CONTENT_TYPE,
        header::ACCEPT,
    ] {
        if let Some(value) = parts.headers.get(&name) {
            outgoing = outgoing.header(name, value)
        }
    }
    if let Some(value) = parts.headers.get("x-csrf-token") {
        outgoing = outgoing.header("x-csrf-token", value)
    }
    for value in parts.headers.get_all("idempotency-key").iter() {
        outgoing = outgoing.header("idempotency-key", value.clone())
    }
    let result = tokio::time::timeout(DEADLINE, async {
        let response = outgoing.send().await?;
        let status = response.status();
        let headers = response.headers().clone();
        let mut stream = response.bytes_stream();
        let mut body = Vec::new();
        while let Some(chunk) = stream.next().await {
            let chunk = chunk?;
            anyhow::ensure!(
                body.len() + chunk.len() <= MAX_RESPONSE,
                "control_response_too_large"
            );
            body.extend_from_slice(&chunk)
        }
        let mut response = Response::builder().status(status).body(Body::from(body))?;
        forward_response_headers(&headers, &mut response, guest_entry);
        Ok::<_, anyhow::Error>(response)
    })
    .await;
    match result {
        Ok(Ok(response)) => response,
        _ => {
            if let Some(room) = room {
                cluster.invalidate(room).await;
            }
            err(StatusCode::SERVICE_UNAVAILABLE, "room_owner_unavailable").into_response()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::extract::ConnectInfo;
    use std::net::SocketAddr;
    #[test]
    fn guest_rate_context_requires_authenticated_unambiguous_peer() {
        // Use ordinary configuration without changing process-wide environment.
        let direct_source: SocketAddr = "192.0.2.1:1234".parse().unwrap();
        let security = account_security::Security::for_test();
        let mut request = Request::new(Body::empty());
        request.extensions_mut().insert(ConnectInfo(direct_source));
        let expected = security.guest_rate_identity(direct_source, request.headers());
        request
            .headers_mut()
            .insert(GUEST_RATE_IDENTITY, "a".repeat(64).parse().unwrap());
        request
            .headers_mut()
            .insert("x-forwarded-for", "198.51.100.2".parse().unwrap());
        assert_eq!(
            guest_rate_identity(&security, &request, false).unwrap(),
            expected
        );
        assert_ne!(
            guest_rate_identity(&security, &request, true).unwrap(),
            expected
        );
        request
            .headers_mut()
            .insert(GUEST_RATE_IDENTITY, expected.as_str().parse().unwrap());
        assert_eq!(
            guest_rate_identity(&security, &request, true).unwrap(),
            expected
        );
        request
            .headers_mut()
            .append(GUEST_RATE_IDENTITY, expected.as_str().parse().unwrap());
        assert!(guest_rate_identity(&security, &request, true).is_err());
        request.headers_mut().remove(GUEST_RATE_IDENTITY);
        assert!(guest_rate_identity(&security, &request, true).is_err());
        for value in ["a".repeat(65), "G".repeat(64)] {
            request
                .headers_mut()
                .insert(GUEST_RATE_IDENTITY, value.parse().unwrap());
            assert!(guest_rate_identity(&security, &request, true).is_err());
        }
        request.extensions_mut().clear();
        assert!(guest_rate_identity(&security, &request, false).is_err());
    }

    #[test]
    fn only_successful_guest_entry_forwards_each_session_cookie() {
        let mut headers = HeaderMap::new();
        headers.insert(header::CONTENT_TYPE, "application/json".parse().unwrap());
        headers.insert(header::CACHE_CONTROL, "no-store".parse().unwrap());
        headers.insert(header::CONNECTION, "close".parse().unwrap());
        headers.insert(SECRET, "never-forward-peer-secret".parse().unwrap());
        headers.insert(GUEST_RATE_IDENTITY, "a".repeat(64).parse().unwrap());
        for cookie in [
            "rainsync_session=synthetic; HttpOnly; SameSite=Strict; Path=/; Max-Age=7200; Secure",
            "other_synthetic=value; HttpOnly; Path=/",
        ] {
            headers.append(header::SET_COOKIE, cookie.parse().unwrap());
        }
        for (guest_entry, status, expected_cookies) in [
            (true, StatusCode::CREATED, 2),
            (false, StatusCode::CREATED, 0),
            (true, StatusCode::UNAUTHORIZED, 0),
            (true, StatusCode::CONFLICT, 0),
            (true, StatusCode::OK, 0),
        ] {
            let mut response = Response::builder()
                .status(status)
                .body(Body::empty())
                .unwrap();
            forward_response_headers(&headers, &mut response, guest_entry);
            assert_eq!(response.headers()[header::CONTENT_TYPE], "application/json");
            assert_eq!(response.headers()[header::CACHE_CONTROL], "no-store");
            assert!(!response.headers().contains_key(header::CONNECTION));
            assert!(!response.headers().contains_key(SECRET));
            assert!(!response.headers().contains_key(GUEST_RATE_IDENTITY));
            let cookies: Vec<_> = response
                .headers()
                .get_all(header::SET_COOKIE)
                .iter()
                .collect();
            assert_eq!(cookies.len(), expected_cookies);
            if expected_cookies != 0 {
                assert_eq!(
                    cookies,
                    headers
                        .get_all(header::SET_COOKIE)
                        .iter()
                        .collect::<Vec<_>>()
                );
            }
        }
    }
    #[test]
    fn origins_never_accept_credentials_paths_or_remote_plaintext() {
        for origin in [
            "http://example.com",
            "https://node.example/path",
            "https://x@y.example",
            "https://node.example/?x=1",
            "https://node.example/#x",
        ] {
            assert!(normalize_origin(origin).is_err(), "{origin}")
        }
        assert_eq!(
            normalize_origin("http://127.0.0.1:8201/").unwrap(),
            "http://127.0.0.1:8201"
        );
    }
    #[test]
    fn media_routes_never_enter_the_room_control_proxy() {
        let room = Uuid::new_v4();
        assert_eq!(
            room_path(&format!("/api/v1/rooms/{room}/timeline/current")),
            Some(room)
        );
        for tail in ["permissions", "permissions/user", "members/user"] {
            assert_eq!(
                room_path(&format!("/api/v1/rooms/{room}/{tail}")),
                Some(room)
            );
        }
        for tail in [
            "playback-plan",
            "compute/jobs",
            "platform-media",
            "sources",
            "p2p",
        ] {
            assert!(room_path(&format!("/api/v1/rooms/{room}/{tail}")).is_none())
        }
    }
}

#[cfg(test)]
mod http_policy_contract;

#[cfg(test)]
mod route_contract;

#[cfg(test)]
mod peer_contract;

#[cfg(test)]
mod start_contract;
