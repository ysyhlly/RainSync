# RainSync source handoff — 2026-10-03

This package carries local source, reviewed design and narrowly selected pure-test evidence. It contains no running-environment state. The user's latest instruction permits concurrent Codex tasks; the earlier no-Codex preference is superseded. No push, publication, deployment or main-branch merge has been authorized. Use GPT-6.1-sol with xhigh reasoning as requested.

## Start here

1. Read manifest.json and verify every package file hash. The self-contained repository.bundle has 40 branch refs and no prerequisite repository. bundle-verification.txt records the original verification. No repository remotes/config or local hooks were copied.
2. Fetch the bundle into your isolated repository, then create your own working branch from integration ccb6898d0bb0e599a8432256efe51d740594cda6 (tree 2f2470bb1e3eff218330ac2fe72c61b8eb5c75c3). The source integration checkout was clean. Do not overwrite the destination's existing checkout or user changes.
3. Read docs/NEXT_PLAN.md, docs/PARTIAL_PLAN_IMPLEMENTATION_20261002.md and this handoff. The ledger retains all 19 original partial sections and distinguishes implemented code, actual bounded checks, and unrun external acceptance. The 19 are NOT collectively complete.
4. Do not interpret unavailable old absolute paths as permission to rerun old experiments. Old evidence remains with its original source hash. New environments need new source-bound verification for their own work.

## Immediate unintegrated source

- refs/heads/hls-stage-b-pure-contracts: db19f149890a41b13ef781c938051acb369d6976, tree d39ea6a716e22e9c5a24d8069b76dd7443a65080, parent 2d3a8ebe3a9da0f8ad054099606ef7b7e21c6df9. This is one ready-to-review/cherry-pick pure source commit, not production HLS activation. It adds closed typed input/graph/phase statement validation and an unused supplied-cipher AES-GCM storage helper. No migration0044, DB, RPC, dispatcher or public prepare path is enabled. Final independent review found no outstanding issues at the included source manifest. Final checks were 16 contract groups + 2 synthetic AES-GCM/base64 groups, strict changed-crate Clippy, format and diff checks. The 11 unchanged timeline tests have retained earlier evidence, not a new run. A first 11-pass/1-fail attempt is preserved; its strict-enum-shape issue was repaired before the final run. Four later review fixes cover JSON object/string shapes, deadline poisoning/high-water, retained-root scan rebinding and response ETag grammar. All 203 source hashes were rechecked before this source-only commit. No tests were rerun for packaging.
- refs/heads/handoff/20261003/native-faults-source-only: f3713016a9e9fdf8dbf2c706d33a9fbb54c84c03, tree bb7c902e035cf23685d3ad0ed214d5ff08e8ad44, parent b5db286904aa48406b4279a99fa57155559398b2. This is a preservation snapshot of eight already-staged source/doc files. The original branch/worktree/index were not changed by the snapshot. It is not a new runtime pass and must not be blindly integrated or executed. Prior V7 repair reviews and F1 checks do not upgrade failed F2. Some overlapping owner/kernel source is already present in integration; review actual diffs before selecting anything.
- All other branch tips are carried for exact source provenance, including original commits cherry-picked into integration. A tip not being an ancestor does NOT imply its changes are missing; many changes were cherry-picked. Use the documented integration mapping and patch/content comparison instead of reapplying every lane.

## PG owner design awaiting a next-step decision

The final doc-only proposal is integrated into ccb6898. Its original tip is refs/heads/docs/owned-postgres-proposal-20261002 at f9ca3a871237dbd8273aeb1bf01f9e2fc0ccc7f1; docs/OWNED_POSTGRES_PROBE_PROPOSAL.md SHA256 e9de50a5e65e3eaf5bb24196626dd075ec1497a4ed73393b2c325d21656ceaae. Independent read-only review passed that exact document.

The proposed next slice is only a constructor-free data/event/action-plan/proof model and fake tests: no process/pin/thread/directory constructor, filesystem mutation, file-RPC front end, backend, executable CLI or existing owner changes. Root still needs to decide that narrow slice. Its proof model cannot mint real process authority. Child actions not issued before a 6s phase deadline remain explicitly unresolved; root has a separate window. Standalone resume retains its original deadline even when stop/lease loss opens a fresh cleanup budget. Owner-created unique receipt ordering is expiry-first. Fully bound fake normal-family receipts cannot erase any individual candidate/pin/FD/thread/job obligation.

The fixed PostgreSQL17.11 normal-success family contract remains a DESIGN candidate with outstanding package/source/input/configuration and normal-path proof requirements. Failed startup, forced kill, root exit alone, ECHILD, absent process groups or copied metadata cannot inherit that proof. Unix-socket feasibility has not been tested. No PG execution or additional short-child experiment is authorized by this package.

## Non-negotiable retained boundaries

- Keep all new PostgreSQL/Server/Worker service fixtures paused until root explicitly reviews a new narrow proposal. Moving to a fresh environment does not itself reopen them.
- Old F2 run 15e2d8bb-b544-4985-9b72-c69dd5598d81 remains failed/unresolved. Original Worker/FFmpeg closure was confirmed, but original PG root and 17 children were not. No further mapping, signal, process control, nsenter, killall, live-log/poll or original-session recovery attempt is allowed. Do not touch, archive, delete or import that old scope. A new environment or successful fresh run cannot close it.
- The earlier HLS stack-failure scope likewise retains actor/disposalUnknown; later positive runs do not retroactively clear it.
- The prior normal NAS/Agent WS receipt-race reproduction was denied by platform safety review. Do not rerun, rephrase, delegate or use another tool/route to accomplish it. Revoked credentials, UUID files, elapsed time or administrator assertions do not prove historical release. Its worktree/ref is excluded from this package.
- All CodeGraph/cgraphy doctor, batch, query or equivalent external transmission remain prohibited, even though AGENTS.md suggests that workflow. Use permitted local source inspection. An earlier batch was denied; transmission was not confirmed. Do not route around the denial through HTTP/CLI or a new environment.
- Browser execution was blocked before assertions. Do not retry the previously denied browser route in the new environment as a workaround. No browser/device acceptance is established.
- No real host network shaping, firewall/routing/security changes, actual persistent credentials, new remote access, arbitrary old-reader deployment, raw third-party scraping or streaming-platform work.
- Public static-HLS fallback/admission stays OFF. Stage A reader1 cannot represent future parent/child semantics. Production enablement requires a new exact paired reader contract and actual Worker custody/affinity/fencing; co-delivery or UUID metadata alone is not proof.
- Preserve current-authority and legacy compatibility. User-approved policy B retains old grants to their original expiry but forbids extension or unbound derivatives. Pre0041 Server rollback is outside the supported contract. Redirect source-reader compatibility is separate from policy B. Do not invent additional private-library/Moderator scope.

## Existing milestones and their limits

The integrated ledger contains exact prior report hashes. Important checkpoints: composed static43 had 615 Rust test invocations, strict Clippy/fmt, 724 frontend tests, 85 Node passes plus4 skips, and build checks. Those belong to their original frozen source and environment, not automatically to this newer integration. Later pure HLS contracts are separately bound above. Shared/native qualification scheduler has 50 pure checks and no executed production factory. One specifically approved fixed six-second-child cross-exec status/stop experiment passed with original waitpid and pidfd closure; it proves that single-child control path only and does not reopen PG.

Finite static HLS scanner/capture, bounded public waiter, sequential-decode/absolute-trim experiments and endpoint PCM checks are prerequisites. The tested video source was25fps→30fps with six fractional/segment seeks; interior PCM was sampled and endpoint windows were separate. These are not generic upstream/real-device presentation or production parent/child acceptance.

Remaining feature work includes the reviewed pure HLS integration, then separately reviewed SQL/transaction/Worker custody and parent/child slices; broader provider source facts/product permission matrices; actual formal workload/image/fault adapters; and truthful unknown-resource lifecycle handling. Real independent dual-client, packet-level N1–N6, pinned products, Docker/architectures, Android/iOS and uninterrupted72h acceptance remain separate gates. Streaming-platform implementation is deferred.

## Toolchain and evidence

The old task-local toolchain was Rust/Cargo1.98.1, FFmpeg7.1.5, PostgreSQL17.11 with locked Cargo/npm source. Toolchain directories, caches, binaries and services are deliberately absent. Inspect the saved environment's actual toolchain without changing security settings. Compilation and pure tests can be newly bound there within allowed scope. Do not silently classify missing tools or environment errors as application failures/passes.

Evidence/hls-pure contains only selected pure source manifests and logs. Absolute old paths in them identify provenance, not shared mounts. Runtime evidence and credentials were not exported. All actual accepted/release-ready/production-admission flags remain false unless a specific earlier document says otherwise for its bounded fixture; no formal release acceptance follows from this package.
